<div id="fur-bottom-footer">
  <div class="row">
    <div class="col-md-4"></div>
    <div class="col-md-4 text-center">
      <p>&copy; 2016 Furnimade All Rights Reserved</p>
      <!-- <p>Developed By <a href="http://dzillaweb.com/">Dzilla Web</a></p> -->
    </div>
    <div class="col-md-4"></div>
  </div>
</div>