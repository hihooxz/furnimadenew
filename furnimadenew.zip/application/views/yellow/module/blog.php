<div class="container">
  <div class="modal-title text-center" style="margin-bottom:25px">
        Furnimade <i class="fa fa-bold" aria-hidden="true"></i>log
  </div>
  <div class="blog-preview">
    <div style="margin-bottom:15px">
    <div class="blog-title">
      <a href="<?php echo base_url('hal/baca-blog/')?>">Lorem Ipsum Dolor Sil Amet</a>
    </div>
    <div class="row">
      <div class="col-md-2">
        <i class="fa fa-pencil" aria-hidden="true"></i>  Created by: Iwen
      </div>
      <div class="col-md-2">
        <i class="fa fa-clock-o" aria-hidden="true"></i>  02 Oct 2016
      </div>
      <div class="col-md-2">
        <i class="fa fa-eye" aria-hidden="true"></i>  Dilihat 47 kali
      </div>
      <div class="col-md-6"></div>
    </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/sofa.png')?>">
      </div>
      <div class="col-md-9">
        <p>Lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet</p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-9">
        <a href="<?php echo base_url('hal/baca-blog/')?>">
          <button class="btn btn-md fur-btn-primary" style="border-radius:0px">Read More <i class="fa fa-chevron-circle-right" aria-hidden="true"></i></button>
        </a>
      </div>
    </div>
  </div>
    <div class="blog-preview">
    <div style="margin-bottom:15px">
    <div class="blog-title">
      <a href="<?php echo base_url('hal/baca-blog/')?>">Lorem Ipsum Dolor Sil Amet</a>
    </div>
    <div class="row">
      <div class="col-md-2">
        <i class="fa fa-pencil" aria-hidden="true"></i>  Created by: Iwen
      </div>
      <div class="col-md-2">
        <i class="fa fa-clock-o" aria-hidden="true"></i>  02 Oct 2016
      </div>
      <div class="col-md-2">
        <i class="fa fa-eye" aria-hidden="true"></i>  Dilihat 47 kali
      </div>
      <div class="col-md-6"></div>
    </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/sofa.png')?>">
      </div>
      <div class="col-md-9">
        <p>Lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet</p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-9">
        <a href="<?php echo base_url('hal/baca-blog/')?>">
          <button class="btn btn-md fur-btn-primary" style="border-radius:0px">Read More <i class="fa fa-chevron-circle-right" aria-hidden="true"></i></button>
        </a>
      </div>
    </div>
  </div>
    <div class="blog-preview">
    <div style="margin-bottom:15px">
    <div class="blog-title">
      <a href="<?php echo base_url('hal/baca-blog/')?>">Lorem Ipsum Dolor Sil Amet</a>
    </div>
    <div class="row">
      <div class="col-md-2">
        <i class="fa fa-pencil" aria-hidden="true"></i>  Created by: Iwen
      </div>
      <div class="col-md-2">
        <i class="fa fa-clock-o" aria-hidden="true"></i>  02 Oct 2016
      </div>
      <div class="col-md-2">
        <i class="fa fa-eye" aria-hidden="true"></i>  Dilihat 47 kali
      </div>
      <div class="col-md-6"></div>
    </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/sofa.png')?>">
      </div>
      <div class="col-md-9">
        <p>Lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet lorem ipsum dolor sil amet</p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-9">
        <a href="<?php echo base_url('hal/baca-blog/')?>">
          <button class="btn btn-md fur-btn-primary" style="border-radius:0px">Read More <i class="fa fa-chevron-circle-right" aria-hidden="true"></i></button>
        </a>
      </div>
    </div>
  </div>
</div>