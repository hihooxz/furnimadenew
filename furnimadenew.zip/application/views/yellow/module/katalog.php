<div class="container" style="margin-bottom:70px">
  <div class="modal-title text-center" style="margin-bottom:25px">
        Furnimade Katalog
  </div>
  <div class="row text-center btn-produk" style="margin-top:20px">
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/wallpaper.jpg') ?>">
        <b>Wallpaper</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/lantai.jpg') ?>">
        <b>Lantai</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/hiasan.jpg') ?>">
        <b>Hiasan Lantai</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/tirai.jpg') ?>">
        <b>Tirai</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/lampu_gantung.jpg') ?>">
        <b>Lampu Gantung</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/lampu_lantai.jpg') ?>">
        <b>Lampu Lantai</b>
      </a>
    </div>
  </div>
  <div class="row text-center btn-produk" style="margin-top:20px">
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/wallpaper.jpg') ?>">
        <b>Wallpaper</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/lantai.jpg') ?>">
        <b>Lantai</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/hiasan.jpg') ?>">
        <b>Hiasan Lantai</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/tirai.jpg') ?>">
        <b>Tirai</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/lampu_gantung.jpg') ?>">
        <b>Lampu Gantung</b>
      </a>
    </div>
    <div class="col-md-2 col-sm-4 col-xs-6">
      <a href="#" title="Lihat Sofa Ketje">
        <img class="img-responsive" src="<?php echo base_url('asset/asset_yellow/images/lampu_lantai.jpg') ?>">
        <b>Lampu Lantai</b>
      </a>
    </div>
  </div>
</div>