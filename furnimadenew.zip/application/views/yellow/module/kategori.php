<div class="container" style="margin-bottom:70px">
  <div class="modal-title text-center" style="margin-bottom:25px">
        Lihat Katalog dari Sofa
  </div>
  <div class="row text-center btn-produk" style="margin-top:20px">
  
    <div class="col-md-3 col-sm-4 col-xs-6 slick">
      <a href="#" title="Lihat Sofa 1">
        <img class="img" width="250" height="180" src="<?php echo base_url('asset/asset_yellow/images/sofa1.jpg') ?>">
        <b>Sofa 1</b><br/>
        <span class="produk-disc"><strike>7,120,000</strike> <b>25% off</b></span><br/>
        Rp 6,408,000
      </a>
    </div>

    <div class="col-md-3 col-sm-4 col-xs-6 slick">
      <a href="#" title="Lihat Sofa 2">
        <img class="img" width="250" height="180" src="<?php echo base_url('asset/asset_yellow/images/sofa2.jpg') ?>">
        <b>Sofa 2</b><br/>
        <span class="produk-disc"><strike>7,120,000</strike> <b>25% off</b></span><br/>
        Rp 6,408,000
      </a>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-6 slick">
      <a href="#" title="Lihat Sofa 3 ">
        <img class="img" width="250" height="180" src="<?php echo base_url('asset/asset_yellow/images/sofa3.jpg') ?>">
        <b>Sofa 3</b><br/>
        <span class="produk-disc"><strike>7,120,000</strike> <b>25% off</b></span><br/>
        Rp 6,408,000
      </a>
    </div>
    <div class="col-md-3 col-sm-4 col-xs-6 slick">
      <a href="#" title="Lihat Sofa 4">
        <img class="img" width="250" height="180" src="<?php echo base_url('asset/asset_yellow/images/sofa4.jpg') ?>">
        <b>Sofa 4</b><br/>
        <span class="produk-disc"><strike>7,120,000</strike> <b>25% off</b></span><br/>
        Rp 6,408,000
      </a>
    </div>
  </div>
</div>