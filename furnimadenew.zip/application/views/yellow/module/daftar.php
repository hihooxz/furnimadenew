<div class="container" style="margin-bottom:25px">
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6 text-center modal-title">
      <div style="margin-bottom:20px">
        <i class="fa fa-user" aria-hidden="true"></i> Daftar
      </div>
            <div class="input-group margin-bottom-sm form-group">
              <span class="input-group-addon modal-fa"><i class="fa fa-user fa-fw" aria-hidden="true"></i></span>
                <input class="form-control" type="text" placeholder="Username">
            </div>
            <div class="input-group margin-bottom-sm form-group">
              <span class="input-group-addon modal-fa"><i class="fa fa-key fa-fw" aria-hidden="true"></i></span>
                <input class="form-control" type="text" placeholder="Password">
            </div>
            <div class="input-group margin-bottom-sm form-group">
              <span class="input-group-addon modal-fa"><i class="fa fa-key fa-fw" aria-hidden="true"></i></span>
                <input class="form-control" type="text" placeholder="Konfirmasi Password">
            </div>
            <div class="input-group margin-bottom-sm form-group">
              <span class="input-group-addon modal-fa"><i class="fa fa-envelope-o fa-fw" aria-hidden="true"></i></span>
                <input class="form-control" type="text" placeholder="Alamat Email">
            </div>
            <button class="btn btn-md form-control fur-btn-primary" style="border-radius:0px" type="submit">Daftar</button>
    </div>
    <div class="col-md-3"></div>
  </div>
</div>