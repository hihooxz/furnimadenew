<div class="pull-right hidden-xs">
  <b></b>
</div>
<strong></a></strong>
